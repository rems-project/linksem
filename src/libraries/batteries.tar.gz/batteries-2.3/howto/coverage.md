Test Coverage
-------------

First, you need to install `bisect` and `qtest`:

    $ opam install bisect qtest

Then, run

    $ make coverage

Then open the file `coverage/index.html` to see how many tests you need to write :)
