# ocaml-uint

This project has been superseded by
[ocaml-stdint](https://github.com/andrenth/ocaml-stdint).

Bug fixes will still be applied here but new development will only happen in
the new repository.
