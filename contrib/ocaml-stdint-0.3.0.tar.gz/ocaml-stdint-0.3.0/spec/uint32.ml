#load "stdint.cma";;
open Stdint.Uint32;;
#use "spec/common.ml";;
